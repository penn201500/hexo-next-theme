---
categories : "python"
description : "python脚本爬取今日百度热点新闻"
tags : "python"
title : "python脚本爬取今日百度热点新闻"
comments : true
date : 2016-07-25T22:04:40Z
---

---
python脚本爬取今日百度热点新闻

## 目标：
python脚本爬取今日百度热点新闻

## 知识点：
1. python3使用 urllib.request.urlopen 去打开一个特定网址
2. 中文可以加 decode('gbk') 来避免乱码
3. re.S 用来解决跨行匹配的问题，用法： re.compile(pattern, re.S)


## 代码

```python
import urllib.request
import re

url : 'http://news.baidu.com/'
content : urllib.request.urlopen(url).read().decode('gbk')

#Example：
#<li class:"hdline0">
#<i class:"dot"></i>
#<strong>
#<a href:"http://china.huanqiu.com/article/2016-07/9209287.html?from:bdwz " target:"_blank" class:"a3" mon:"ct:1&amp;a:1&amp;c:top&amp;pn:0">xxx：扶贫工作不搞层层加码</a>
#</strong>
#</li>

pattern : re.compile('<li class:"hd.*?<strong>.*?<a.*?>(.*?)</a>.*?strong>', re.S)
hotNews : re.findall(pattern, content)

for i in hotNews:
  print(i)
```

## hotnews from baidu:

![](http://o7ubfyghw.bkt.clouddn.com/baidu%20hotnews.jpg)

## script excute result:

![](http://o7ubfyghw.bkt.clouddn.com/crawler%20baidu%20hotNews.jpg)




* * *

