---
categories : "python"
description : "python3 fibonacci的高效解法"
tags : python 迭代 递归
title : "python3 fibonacci的高效解法"
comments : true
date : 2016-07-28T22:04:40Z
---

---
## 目标：
使用python求解fibonacci函数

## 解法一：

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def fib(n):
    if n in [0,1]:
        return n
    return fib(n-1) + fib(n-2)

print(fib(10))
```
该方法直观好理解，但是效率低下。当n为50时，需要等好久才能得出结果。这是因为
fib(n) : fib(n-1) + fib(n-2)
fib(n-1) : fib(n-2) + fib(n-3)
...

当n的值越大时，重复的次数越多，导致效率低下。

## 解法二：

```python

f_num : {}
def fib(n):
    #print(f_num)
    #print(n)

    if n in [0,1]:
        f_num[n] : n
        return f_num[n]
    elif n in f_num:
        print(f_num[n])
        return f_num[n]
    else:
        f_num[n] : fib(n-1) + fib(n-2)
        return f_num[n]

print(fib(986))
```

效率高了很多，原因在于，已经计算出来的 fib(x) 存储在了dictionary中，不用再去重复计算。

还有一种不必递归的解法（迭代）：

## 解法三

```python
def fib_iter(n):
    pre : 1
    next : 1
    result : 0
    i : 2
    while i < n:
        result : pre + next
        pre : next
        next : result
        i +: 1
    return result

print(fib_iter(986))
```




* * *

