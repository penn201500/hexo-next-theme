---
categories : "vim"
description : "vim spf13"
tags : "vim"
title : "linux mint 18上安装vim spf13 "
comments : true
date : 2016-07-04T22:04:40Z
---

---


------

vim的终极配置spf13在linux_mint上的安装步骤如下（非gui）：

1. 安装vim
菜单-->软件管理器-->搜索“vim”。双击vim，安装
![search and install vim](http://o7ubfyghw.bkt.clouddn.com/mint%20install%20vim.jpg)

2. 安装vim-nox
与安装vim一样，搜索vim-nox；使用vim spf13中的neocomplete功能，需要vim有lua特性支持。vim-nox安装之后，查看vim的version信息：
![vim version with lua support](http://o7ubfyghw.bkt.clouddn.com/spf13%20lua%20support.jpg)

3. 安装spf13
访问spf13官网：http://vim.spf13.com/
打开terminal，输入：

  >curl http://j.mp/spf13-vim3 -L -o - | sh

  然后等待安装完成。
  如果安装失败，提示git或者curl未安装:
  
  >sudo apt-get install git
sudo apt-get install curl

4. 配置color-scheme，NerdTree，字体
安装完成之后，在.spf13-vim-3同一级目录下，有

  >.vimrc
.vimrc.before
.vimrc.bundles
.viminfo

  使用molokai color-scheme：
  可以在.vimrc.local中配置colorscheme，也可以vim中执行命令，如：
  ![molokai color-scheme](http://o7ubfyghw.bkt.clouddn.com/colorshceme%20molokai.jpg)
  
  配置NerdTree标签：需要在与.spf13-vim-3同一级目录下创建文件.NERDTreeBookmarks 文件中内容如下：
  
  >.spf13-vim-3 ~/.spf13-vim-3
  
  这样会在NERDTree的标签中显示标签 `.spf13-vim-3`
  ![nerdtree bookmark](http://o7ubfyghw.bkt.clouddn.com/spf13%20bookmarks.jpg)
  
  添加.vimrc.local:
  与.spf13-vim-3同一级目录下创建文件.vimrc.local，用来做个性化配置。如：
  
  >"::::::::::::::::快捷换行::::::::::::::::::
nmap <c-up> ddkP
nmap <c-down> ddp
vmap <c-up> xkP`[V`]
vmap <c-down> xp`[V`]
" ::::::: 使nerd-tree 能够copy文件 ::::::: " 
let g:NERDTreeCopyCmd : 'cp -r '

  配置NerdTree打开时显示的路径：
  在.vimrc.local中增加
  
  >" ::::::: 设置NERDTree打开时的目录 ::::::: "
cd /home/mint/python_projects
" shortcut to toggle NerdTree
map <F2> :NERDTreeToggle<CR>    
" open Nerd Tree in folder of file in active buffer
map <Leader>nt :NERDTree %:p:h<CR>
autocmd bufenter * if (winnr("$") :: 1 && exists("b:NERDTreeType") && b:NERDTreeType :: "primary") |q| endif

  添加.vimrc.bundles.local 用来配置自己的插件，如：
  
  >Bundle 'mhinz/vim-startify'
  
  添加自己的插件之后，执行命令插件：
  >vim +BundleInstall! +BundleClean +q

  在.vimrc.local中配置字体：
  >" ::::::: 自定义快捷键 ::::::: "
" 设置着色模式和字体
colorscheme molokai
set guifont:Monaco:h11
" AirLine             彩色状态栏
let g:airline_theme : 'dark'                " 设置主题



* * *

