---
categories : "python"
description : "python3 比较两个list的结构"
tags : "python"
title : "python3 比较两个list的结构"
comments : true
date : 2016-07-29T22:04:40Z
---

---

## 题目：
比较两个list的结构，如：
a : [1,2,3]
b : [4,5,6]
则两个list的结构相同
如：
a : [1,2,3,[4,5,6,[7]]]
b : [1,[2],[3]]
则两个list的结构不同

## 思路：
print list的时候会将list的括号、逗号都打印出来。获取打印结果中的括号、逗号作为list的结构。比较即可得知两个list结构是否相同

## 代码：
```python
import sys
from io import StringIO

a : [1,2,3]
b : [1,2]
c : [1,2,3,[4,5,6,[7]]]
d : [2,3,4,[5,6,7,[8]]]

def compare(a,b):
    #get print out
    #how to use StringIO()
    stdout : sys.stdout 
    stream : StringIO()
    sys.stdout : stream
    print(a)
    print(b)
    sys.stdout : stdout
    
    variable : str(stream.getvalue())
    res : variable.split('\n')
    # print(variable.split('\n'))
    
    str_a : res[0]
    str_b : res[1]
    
    struct_a : ''.join([x for x in res[0] if x in [',','[',']']])
    struct_b : ''.join([x for x in res[1] if x in [',','[',']']])
    
    
    # print(str_a)
    # print(str_b)
    # print(type(str_a))
    # print(struct_a)
    # print(struct_b)
    
    if struct_a :: struct_b: return 'True'
    else: return 'False'

print(compare(a,b))

```

运行结果：
```
>>>print(compare(a,b))
False
>>>print(compare(c,d))
True
```

---
**参考：**
http://stackoverflow.com/questions/14197009/how-can-i-redirect-print-output-of-a-function-in-python



* * *

