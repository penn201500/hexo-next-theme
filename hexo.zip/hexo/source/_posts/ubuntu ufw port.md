---
categories : "Linux"
description : "Linux ubuntu"
tags : "ufw"
title : "ubuntu的ufw如何开放特定端口?"
comments : true
date : 2016-07-15T23:04:40Z
---

---
ufw是一个主机端的iptables类防火墙配置工具

## 安装：

>sudo apt-get install ufw

## 开启，建议默认关闭所有外部访问

>sudo ufw enable

>sudo ufw default deny

## 查看ufw现在已经开放的端口：

>ubuntu@localhost:~$ sudo ufw status
[sudo] password for ubuntu: 
Status: active

>| To        | Action   |  From  |
| :--------   | :-----:  | :----:  |
|\--     | \------  |    \---- |
|16430          |            ALLOW   |    Anywhere
|30000           |           ALLOW    |   Anywhere
|30001            |          ALLOW     |  Anywhere
|1194/tcp          |         ALLOW      | Anywhere
|16430 (v6)         |        ALLOW       |Anywhere (v6)
|30000 (v6)          |       ALLOW  |     Anywhere (v6)
|30001 (v6)           |      ALLOW   |    Anywhere (v6)
|1194/tcp (v6)         |     ALLOW    |   Anywhere (v6)
|ubuntu@localhost:~$ 

## 新增端口

>sudo ufw allow 8080

## 删除端口

>sudo ufw delete allow 8080

## 允许特定来源的ip地址访问

>sudo ufw allow from 192.168.1.1


## 其他命令可以如此查看：

>ubuntu@localhost:~$ sudo ufw --help

>Usage: ufw COMMAND

>Commands:

>enable:enables the firewall

>disable:disables the firewall

>......





* * *

